"""Download immutable Git dependencies for the gsplat v1.5.3 smoke run."""
import concurrent.futures
import hashlib
import json
import tarfile
import time
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SPECS = [
    ('glm', 'g-truc/glm', '33b4a621a697a305bc3a7610d290677b96beb181',
     ROOT / 'third_party/gsplat/gsplat/cuda/csrc/third_party/glm'),
    ('pycolmap_legacy', 'rmbrualla/pycolmap', 'cc7ea4b7301720ac29287dbe450952511b32125e',
     ROOT / 'third_party/pycolmap_legacy'),
    ('nerfview', 'nerfstudio-project/nerfview', '4538024fe0d15fd1a0e4d760f3695fc44ca72787',
     ROOT / 'third_party/nerfview'),
    ('fused_ssim', 'rahul-goel/fused-ssim', '328dc9836f513d00c4b5bc38fe30478b4435cbb5',
     ROOT / 'third_party/fused_ssim'),
]


def fetch(spec):
    name, repository, commit, target = spec
    receipt = ROOT / 'research' / (name + '_source.json')
    if receipt.is_file() and target.is_dir() and any(target.iterdir()):
        result = json.loads(receipt.read_text())
        if result['commit'] != commit:
            raise ValueError('Existing source commit differs: ' + name)
        return result
    url = f'https://codeload.github.com/{repository}/tar.gz/{commit}'
    archive = ROOT / 'research' / (name + '-' + commit[:12] + '.tar.gz')
    for attempt in range(3):
        try:
            with urllib.request.urlopen(url, timeout=90) as response, archive.open('wb') as stream:
                while chunk := response.read(1 << 20):
                    stream.write(chunk)
            break
        except Exception:
            if attempt == 2:
                raise
            time.sleep(1)
    staging = ROOT / 'research' / ('extract_' + name)
    staging.mkdir(exist_ok=True)
    with tarfile.open(archive) as handle:
        handle.extractall(staging, filter='data')
    children = list(staging.iterdir())
    if len(children) != 1:
        raise ValueError('Unexpected source archive layout: ' + name)
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists():
        if any(target.iterdir()):
            raise ValueError('Refusing to overwrite nonempty directory: ' + str(target))
        target.rmdir()
    children[0].rename(target)
    staging.rmdir()
    result = {'repository': 'https://github.com/' + repository, 'commit': commit,
              'source_url': url, 'directory': str(target),
              'archive_sha256': hashlib.sha256(archive.read_bytes()).hexdigest()}
    receipt.write_text(json.dumps(result, indent=2) + '\n')
    return result


if __name__ == '__main__':
    (ROOT / 'research').mkdir(exist_ok=True)
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executor:
        for result in executor.map(fetch, SPECS):
            print(json.dumps(result), flush=True)
