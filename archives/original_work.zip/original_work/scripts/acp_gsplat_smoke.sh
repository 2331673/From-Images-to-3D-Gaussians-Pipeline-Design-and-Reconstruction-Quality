#!/usr/bin/env bash
# One H100, a frozen gsplat release, one known-pose object, no AFS writes.
set -euo pipefail
project=[ORIGINAL_PROJECT]
run_name=${1:-gsplat_v153_smoke}
[[ "$run_name" =~ ^[a-zA-Z0-9_-]+$ ]] || exit 2
experiment="$project/experiments/$run_name"
scratch=/tmp/3dcv-gsplat-v153
mkdir -p "$experiment" "$scratch" "$project/cache/torch" "$project/cache/pip"
exec > >(tee -a "$experiment/worker.log") 2>&1
export PYTHONDONTWRITEBYTECODE=1 PYTHONUNBUFFERED=1
export PIP_CACHE_DIR="$scratch/pip_cache"
export PIP_CONFIG_FILE=/dev/null PIP_INDEX_URL=https://pypi.org/simple
export PIP_DEFAULT_TIMEOUT=30 PIP_RETRIES=2
export PIP_NO_INDEX=1 PIP_FIND_LINKS="$scratch/wheels"
unset PIP_EXTRA_INDEX_URL PIP_TRUSTED_HOST
export TORCH_HOME="$project/cache/torch"
export TORCH_EXTENSIONS_DIR="$scratch/torch_extensions"
export CUDA_CACHE_PATH="$scratch/cuda_cache"
export XDG_CACHE_HOME="$scratch/cache"
export MPLCONFIGDIR="$scratch/matplotlib"
export CUDA_CACHE_DISABLE=0 MAX_JOBS=4 OMP_NUM_THREADS=4
export TORCH_CUDA_ARCH_LIST=9.0
export CUDA_HOME=/usr/local/cuda
export PATH="$CUDA_HOME/bin:$PATH"
export EXPERIMENT_DIR="$experiment"
stage=bootstrap
finish() {
  exit_code=$?
  trap - EXIT
  python3 - "$exit_code" "$stage" <<'PY'
import json, os, sys
from datetime import datetime, timezone
from pathlib import Path
out = Path(os.environ['EXPERIMENT_DIR'])
data = {'exit_code': int(sys.argv[1]), 'last_stage': sys.argv[2],
        'finished_at_utc': datetime.now(timezone.utc).isoformat(),
        'status': 'complete' if sys.argv[1] == '0' else 'failed'}
(out / 'worker_status.json').write_text(json.dumps(data, indent=2) + '\n')
print(json.dumps(data), flush=True)
PY
  exit "$exit_code"
}
trap finish EXIT
mark_stage() {
  stage=$1
  python3 - "$stage" <<'PY'
import json, os, sys
from datetime import datetime, timezone
from pathlib import Path
data = {'stage': sys.argv[1], 'updated_at_utc': datetime.now(timezone.utc).isoformat()}
Path(os.environ['EXPERIMENT_DIR'], 'worker_progress.json').write_text(json.dumps(data)+'\n')
print(json.dumps(data), flush=True)
PY
}
mark_stage bootstrap
date -u
python3 "$project/scripts/acp_preflight.py"
mkdir -p "$scratch/wheels"
cp "$project"/wheels/*.whl "$scratch/wheels/"

# Preserve the image's matched NVIDIA torch/torchvision pair in an isolated venv.
python3 -m pip install --disable-pip-version-check --target "$scratch/bootstrap" virtualenv==20.26.6
PYTHONPATH="$scratch/bootstrap" python3 -m virtualenv --system-site-packages \
  --app-data "$scratch/virtualenv_appdata" --no-periodic-update "$scratch/venv"
py="$scratch/venv/bin/python"
"$py" - <<'PY'
from pathlib import Path
from importlib.metadata import version
import torch, torchvision
Path('/tmp/3dcv-gsplat-v153/torch-constraints.txt').write_text(
    'torch==' + version('torch') + '\ntorchvision==' + version('torchvision') + '\n')
assert torch.cuda.is_available(), 'GPU unavailable'
print('Using image torch', torch.__version__, 'CUDA', torch.version.cuda, flush=True)
PY
mark_stage python_dependencies
# NVIDIA's matched image reports torch as 2.3.0a0; allow that prerelease.
"$py" -m pip install --pre --disable-pip-version-check -c "$scratch/torch-constraints.txt" \
  'numpy==1.26.4' 'viser==0.2.23' 'imageio==2.36.1' 'imageio-ffmpeg==0.5.1' \
  'scikit-learn==1.5.2' 'tqdm==4.67.1' 'torchmetrics==1.4.3' \
  'opencv-python-headless==4.10.0.84' 'tyro==0.8.14' 'Pillow==11.0.0' \
  'tensorboard==2.18.0' 'tensorly==0.9.0' 'PyYAML==6.0.2' \
  'matplotlib==3.9.2' 'splines==0.3.2' 'ninja==1.11.1.1' \
  'jaxtyping==0.2.36' 'rich==13.9.4' 'typing_extensions==4.12.2' 'plyfile==1.1'

# Build locally; preserve all authoritative sources and outputs in AOSS.
mark_stage stage_sources
mkdir -p "$scratch/src"
cp -r "$project/third_party/gsplat" "$scratch/src/"
cp -r "$project/third_party/pycolmap_legacy" "$scratch/src/"
cp -r "$project/third_party/nerfview" "$scratch/src/"
cp -r "$project/third_party/fused_ssim" "$scratch/src/"
mark_stage build_extensions
mkdir -p "$scratch/built_wheels"
"$py" -m pip wheel --no-build-isolation --no-deps --wheel-dir "$scratch/built_wheels" \
  "$scratch/src/pycolmap_legacy" "$scratch/src/nerfview" \
  "$scratch/src/fused_ssim" "$scratch/src/gsplat"
"$py" -m pip install --no-deps "$scratch"/built_wheels/*.whl
mkdir -p "$project/built_wheels/py310_torch230nv_cuda124_sm90"
cp "$scratch"/built_wheels/*.whl "$project/built_wheels/py310_torch230nv_cuda124_sm90/"
"$py" -m pip freeze --all > "$experiment/environment.freeze.txt"
"$py" - <<'PY'
import json, os, sys, torch, numpy, gsplat, pycolmap, fused_ssim
from pathlib import Path
data = {'python': sys.version, 'torch': torch.__version__, 'numpy': numpy.__version__,
        'gsplat': gsplat.__version__, 'torch_cuda': torch.version.cuda,
        'legacy_colmap_scene_manager': hasattr(pycolmap, 'SceneManager'),
        'gpu': torch.cuda.get_device_name(0)}
Path(os.environ['EXPERIMENT_DIR'], 'runtime.json').write_text(json.dumps(data, indent=2)+'\n')
print(data, flush=True)
PY
mark_stage stage_data
mkdir -p "$scratch/scene"
cp -r "$project/data/smoke_vending/." "$scratch/scene/"
mark_stage train
cd "$scratch/src/gsplat/examples"
"$py" simple_trainer.py default \
  --data-dir "$scratch/scene" --data-factor 1 --result-dir "$experiment/model" \
  --disable-viewer --disable-video --no-normalize-world-space \
  --max-steps 2000 --eval-steps 1 500 2000 --save-steps 2000 \
  --save-ply --ply-steps 2000
mark_stage render_orbit
"$py" "$project/scripts/render_smoke_orbit.py" \
  --checkpoint "$experiment/model/ckpts/ckpt_1999_rank0.pt" \
  --config "$experiment/model/cfg.yml" --output "$experiment/orbit.gif"
mark_stage complete
