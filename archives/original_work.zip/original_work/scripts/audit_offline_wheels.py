"""Check wheel requirements against the recorded ACP image and staged wheels."""
import email
import json
import zipfile
from pathlib import Path
from packaging.markers import default_environment
from packaging.requirements import Requirement
from packaging.utils import canonicalize_name

ROOT = Path(__file__).resolve().parents[1]
base = json.loads((ROOT / 'research/acp_base_packages.json').read_text())
available = {canonicalize_name(item['name']): item['version'] for item in base}
environment = default_environment()
environment.update(python_version='3.10', python_full_version='3.10.12',
                   sys_platform='linux', platform_system='Linux', extra='')
records = []
for path in sorted((ROOT / 'wheels').glob('*.whl')):
    with zipfile.ZipFile(path) as wheel:
        name = next(item for item in wheel.namelist() if item.endswith('.dist-info/METADATA'))
        metadata = email.message_from_bytes(wheel.read(name))
    record = {'file': path.name, 'name': metadata['Name'], 'version': metadata['Version'],
              'requirements': metadata.get_all('Requires-Dist', [])}
    available[canonicalize_name(record['name'])] = record['version']
    records.append(record)
extras = {}
for _ in range(len(records) + 1):
    changed = False
    for record in records:
        active = extras.get(canonicalize_name(record['name']), set()) | {''}
        for value in record['requirements']:
            requirement = Requirement(value)
            if requirement.marker and not any(requirement.marker.evaluate(
                    dict(environment, extra=extra)) for extra in active):
                continue
            name = canonicalize_name(requirement.name)
            before = extras.get(name, set())
            after = before | requirement.extras
            if before != after:
                extras[name] = after
                changed = True
    if not changed:
        break
missing = []
for record in records:
    active = extras.get(canonicalize_name(record['name']), set()) | {''}
    for value in record['requirements']:
        requirement = Requirement(value)
        if requirement.marker and not any(requirement.marker.evaluate(
                dict(environment, extra=extra)) for extra in active):
            continue
        version = available.get(canonicalize_name(requirement.name))
        if version is None or not requirement.specifier.contains(version, prereleases=True):
            missing.append({'parent': record['name'], 'requirement': value, 'available': version})
result = {'target_python': '3.10.12', 'wheel_count': len(records),
          'base_package_count': len(base), 'missing_requirements': missing, 'wheels': records}
(ROOT / 'research/offline_wheel_audit.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps({key: value for key, value in result.items() if key != 'wheels'}, indent=2))
