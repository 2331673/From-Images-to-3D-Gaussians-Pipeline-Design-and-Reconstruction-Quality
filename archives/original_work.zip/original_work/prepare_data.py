#!/usr/bin/env python3
"""Audit the final Objaverse filter and select existing perspective renders.

Usage:
    python3 prepare_data.py
    python3 prepare_data.py --count 10 --materialize

Default execution writes only small manifests beside this script. --materialize
also copies input images and camera metadata into data/<uid>/. This is data
preparation, not a COLMAP reconstruction or a trained NeRF/3DGS model. Candidate
objects still need visual review for category diversity and matching quality.
"""

import argparse
import ast
import csv
import hashlib
import json
import shutil
import struct
from datetime import datetime, timezone
from pathlib import Path

PROJECT = Path(__file__).resolve().parent
CLEAN = Path('[LOCAL_PATH]')
REPORT = Path('[LOCAL_PATH]')
FINAL_CSV = REPORT / '最终保留资产清单.csv'
FINAL_UIDS = REPORT / '最终保留UID.txt'
CLEAN_SUBSET = CLEAN / 'downstream_validation_2000_v1/manifests/formal_C-clean.json'
# The newer 2,000-object experiment deliberately reuses the v1 image directory.
RENDERS = CLEAN / 'downstream_validation_v1/renders'


def read_json(path):
    return json.loads(path.read_text(encoding='utf-8'))


def read_csv(path):
    with path.open(encoding='utf-8-sig', newline='') as stream:
        return list(csv.DictReader(stream))


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def audit():
    rows = read_csv(FINAL_CSV)
    final = {row['uid']: row for row in rows}
    if len(rows) != len(final):
        raise ValueError('Duplicate UIDs in final asset manifest')
    uids = FINAL_UIDS.read_text(encoding='utf-8-sig').splitlines()
    if len(set(uids)) != len(uids) or set(uids) != set(final):
        raise ValueError('Final CSV and final UID list disagree')

    source_rows = []
    source_paths = []
    for path in sorted(CLEAN.glob('member_b_v2_vlm_*/selection.csv')):
        source_rows.extend(read_csv(path))
        source_paths.append(path)
    source_uids = [row['uid'] for row in source_rows]
    if len(source_uids) != len(set(source_uids)):
        raise ValueError('Duplicate UIDs across filtering runs')
    kept = {row['uid']: row for row in source_rows
            if row['status'] == 'keep_candidate'}
    if set(kept) != set(final):
        raise ValueError('Final manifest is inconsistent with current filtering runs')
    for uid, row in final.items():
        if (row['source_glb'] != kept[uid]['source_path'] or
                row['normalized_glb'] != kept[uid]['normalized_path']):
            raise ValueError(f'Asset paths differ between manifests: {uid}')

    subset = read_json(CLEAN_SUBSET)['uids']
    if len(subset) != len(set(subset)) or not set(subset) <= set(final):
        raise ValueError('Clean subset has duplicate or non-retained UIDs')
    summary = {
        'checked_at_utc': datetime.now(timezone.utc).isoformat(),
        'candidate_count_before_vlm': len(source_rows),
        'final_retained_count': len(final),
        'clean_subset_count': len(subset),
        'current_filter_manifests_match_final': True,
        'final_manifest': str(FINAL_CSV),
        'final_manifest_sha256': sha256(FINAL_CSV),
        'final_uid_list': str(FINAL_UIDS),
        'clean_subset': str(CLEAN_SUBSET),
        'clean_subset_sha256': sha256(CLEAN_SUBSET),
        'render_root': str(RENDERS),
        'selection_manifests': [str(path) for path in source_paths],
    }
    return final, subset, summary


def inspect_poses(path, count):
    # Inspect the standard .npy header using only the Python standard library.
    with path.open('rb') as stream:
        if stream.read(6) != b'\x93NUMPY':
            raise ValueError('Invalid NPY magic')
        version = tuple(stream.read(2))
        if version not in ((1, 0), (2, 0), (3, 0)):
            raise ValueError(f'Unsupported NPY version: {version}')
        length_format = '<H' if version == (1, 0) else '<I'
        length_size = struct.calcsize(length_format)
        header_length = struct.unpack(length_format, stream.read(length_size))[0]
        header = ast.literal_eval(stream.read(header_length).decode(
            'utf-8' if version == (3, 0) else 'latin1').strip())
        if header['shape'] != (count, 4, 4):
            raise ValueError(f'Unexpected camera array shape: {header["shape"]}')
        if header['descr'] not in ('<f4', '>f4', '<f8', '>f8'):
            raise ValueError(f'Unexpected camera dtype: {header["descr"]}')
        expected_size = stream.tell() + count * 16 * int(header['descr'][-1])
        if path.stat().st_size != expected_size:
            raise ValueError('Camera array payload size is incorrect')
    return header


def inspect_candidate(row):
    uid = row['uid']
    directory = RENDERS / uid
    ready = read_json(directory / 'ready.json')
    meta = read_json(directory / 'render.json')
    if ready['uid'] != uid or meta['source'] != row['source_glb']:
        raise ValueError('Rendered asset provenance does not match final manifest')
    if ready['config_sha256'] != meta['config_sha256']:
        raise ValueError('Rendering configuration hashes disagree')
    if meta.get('test') is not False or len(meta['views']) != 30:
        raise ValueError('Expected 30 existing perspective input views')
    if not meta['camera_convention'].startswith('Blender camera-to-world'):
        raise ValueError('Unexpected camera convention')
    for key in ('source_glb', 'normalized_glb'):
        if not Path(row[key]).is_file():
            raise FileNotFoundError(row[key])

    sizes = set()
    images = [directory / f'{index:03d}.png' for index in range(30)]
    for path in images:
        with path.open('rb') as stream:
            header = stream.read(24)
        if header[:8] != b'\x89PNG\r\n\x1a\n' or header[12:16] != b'IHDR':
            raise ValueError(f'Invalid PNG header: {path}')
        sizes.add(struct.unpack('>II', header[16:24]))
    if len(sizes) != 1:
        raise ValueError('Image dimensions differ within one object')
    width, height = sizes.pop()
    if width <= 0 or height <= 0:
        raise ValueError('Invalid image dimensions')
    inspect_poses(directory / 'poses.npy', len(images))
    run = Path(row['normalized_glb']).parents[2]
    return {
        **row,
        'render_dir': str(directory),
        'image_count': len(images),
        'width': width,
        'height': height,
        'camera_convention': meta['camera_convention'],
        'focal_normalized': meta['focal_normalized'],
        'images': [str(path) for path in images],
        'poses': str(directory / 'poses.npy'),
        'render_metadata': str(directory / 'render.json'),
        'ready_marker': str(directory / 'ready.json'),
        'qc_contact_sheet': str(run / 'views' / uid / 'contact_rgb.jpg'),
        'filter_record': str(run / 'records' / f'{uid}.json'),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--count', type=int, default=10)
    parser.add_argument('--materialize', action='store_true',
                        help='Also copy images and camera metadata into this project')
    args = parser.parse_args()
    if args.count < 1:
        parser.error('--count must be positive')

    final, subset, summary = audit()
    candidates = [uid for uid in subset
                  if set(final[uid]['usable_input_view_ids'].split(',')) ==
                  {str(index) for index in range(6)}]
    chosen = []
    skipped = []
    for uid in candidates:
        try:
            chosen.append(inspect_candidate(final[uid]))
        except (OSError, ValueError, KeyError, struct.error, SyntaxError) as error:
            skipped.append({'uid': uid, 'reason': str(error)})
            continue
        if len(chosen) == args.count:
            break
    if len(chosen) != args.count:
        raise RuntimeError(f'Only {len(chosen)} usable objects for requested {args.count}')

    if args.materialize:
        for row in chosen:
            directory = PROJECT / 'data' / row['uid']
            image_dir = directory / 'images'
            image_dir.mkdir(parents=True, exist_ok=True)
            for source in row['images']:
                shutil.copyfile(source, image_dir / Path(source).name)
            for key in ('poses', 'render_metadata', 'ready_marker'):
                source = Path(row[key])
                shutil.copyfile(source, directory / source.name)

    summary.update({
        'six_usable_qc_views_in_clean_subset': len(candidates),
        'selected_count': len(chosen),
        'selection_status': 'preliminary_candidates_for_pipeline_smoke_run',
        'selection_rule': 'First available objects in frozen clean subset order with six usable QC views',
        'validation_scope': 'Manifest consistency, asset existence, PNG headers, NPY header and payload size; no feature matching or reconstruction yet',
        'images_copied': args.materialize,
        'skipped_candidates': skipped,
        'objects': chosen,
    })
    output = PROJECT / 'manifests'
    output.mkdir(parents=True, exist_ok=True)
    path = output / 'candidates.json'
    path.write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n',
                    encoding='utf-8')
    fields = ('uid', 'split', 'source_glb', 'normalized_glb', 'render_dir',
              'image_count', 'width', 'height', 'poses', 'qc_contact_sheet')
    with (output / 'candidates.csv').open('w', encoding='utf-8-sig', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=fields, extrasaction='ignore')
        writer.writeheader()
        writer.writerows(chosen)
    print(json.dumps({key: summary[key] for key in
                      ('final_retained_count', 'clean_subset_count',
                       'six_usable_qc_views_in_clean_subset', 'selected_count',
                       'images_copied')}, ensure_ascii=False))
    print(path)


if __name__ == '__main__':
    main()
